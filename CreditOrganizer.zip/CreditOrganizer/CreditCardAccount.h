#pragma once
#include "LoyaltyScheme.h"
ref class CreditCardAccount
{
public:
	static int GetNumberOfAccounts();
	// ... Other members, as before
	CreditCardAccount(long number, double limit);
	// ... Other members, as before
	void SetCreditLimit(double amount);
	bool MakePurchase(double amount);
	void MakeRepayment(double amount);
	void PrintStatement();
	long GetAccountNumber();
	static CreditCardAccount();
	literal System::String^ name = "Super Platinum Card";
	void RedeemLoyaltyPoints();
private:
	static int numberOfAccounts = 0;
	// ... Other members, as before
	initonly long accountNumber;
	double currentBalance;
	double creditLimit;
	static double interestRate;
	LoyaltyScheme^ scheme; // Handle to a LoyaltyScheme object
};